import pagarme from 'pagarme';

import {useEffect, useState} from 'react';
import {withTheme} from '@rjsf/core';
import {Theme as Bootstrap4Theme} from '@rjsf/bootstrap-4';
import {
  Button,
  Nav,
  Navbar,
  NavDropdown,
  FormControl,
  Form,
  Container,
  Row,
  Col, Badge,
} from 'react-bootstrap';
import tests from './tests';
import schemas from './schemas'

import './App.css';

function App() {
  const SchemaForm = withTheme(Bootstrap4Theme);

  const [schema, setSchema] = useState(null);
  const [formData, setFormData] = useState(null);
  const [response, setResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [apiKey, setApiKey] = useState(localStorage.getItem('pagarme_api_key'));
  const [currentApiKey, setCurrentApiKey] = useState(apiKey);
  const [test, setTest] = useState(null);

  const changeTest = async test => {
    const client = await pagarme.client.connect({api_key: apiKey});
    const state = await test.createState(client);
    const schema = test.generateSchema(state, schemas);

    setSchema(schema);
    setFormData(null);
    setTest(test);
  };

  const executeTest = async test => {
    try {
      const client = await pagarme.client.connect({api_key: apiKey});
      const data = await test.execute(client, formData);

      setResponse({
        success: true,
        data
      })
    } catch (error) {
      if(error.response) {
        setResponse({
          success: false,
          data: error.response
        })
      } else {
        alert(
            'Erro ao executar o teste. Por favor, veja o console de desenvolvedor para mais informações.',
        );
      }

      console.error(error);
    }
  }

  const updateApiKey = () => {
    localStorage.setItem('pagarme_api_key', currentApiKey);
    setApiKey(currentApiKey);
    setCurrentApiKey(currentApiKey);

    alert(
      'API Key atualizada com sucesso, agora você já pode começar os testes!',
    );
    setTest(null);
  };

  useEffect(async () => {
    if (!apiKey) return;

    try {
      const selectedTestOrFirst = test || tests[0];

      setLoading(true);
      await changeTest(selectedTestOrFirst);
      setLoading(false);
    } catch (error) {
      alert(
        'Erro ao carregar o teste. Por favor, veja o console de desenvolvedor para mais informações.',
      );
      console.error(error);

      setLoading(false);
    }
  }, [test]);

  return (
    <div>
      <Navbar bg="light" expand="lg">
        <Navbar.Brand>
          <img
            src="/favicon.png"
            width="30"
            height="30"
            className="d-inline-block align-top mr-3"
            alt="Pagar.me Icon"
          />
          Pagar.me • API Helper
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="mr-auto">
            <NavDropdown
              title={test ? test.title : 'Selecionar teste'}
              id="basic-nav-dropdown"
              disabled={!apiKey}
            >
              {tests.map(test => (
                <NavDropdown.Item onSelect={() => setTest(test)}>
                  {test.title}
                </NavDropdown.Item>
              ))}
            </NavDropdown>
          </Nav>
          <Form inline>
            <FormControl
              type="text"
              placeholder="Pagar.me API Key"
              className="mr-sm-2"
              value={currentApiKey}
              onChange={$event => setCurrentApiKey($event.target.value)}
            />
            <Button variant="outline-success" onClick={updateApiKey}>
              Atualizar key
            </Button>
          </Form>
        </Navbar.Collapse>
      </Navbar>
      <Container fluid className="p-3">
        <Row>
          {!apiKey && <Col>Primeiramente, insira sua API Key da Pagar.me.</Col>}
          {loading && <Col>Carregando...</Col>}
          {!loading && schema && test && (
            <>
              <Col>
                <h2>{test.title}</h2>
                <hr />
                <SchemaForm
                  formData={formData}
                  schema={schema}
                  onSubmit={$event => setFormData($event.formData)}
                >
                  <div>
                    <Button variant="success" className="mr-3" type="submit">
                      Atualizar requisição
                    </Button>
                    <Button variant="outline-secondary" onClick={() => setFormData(null)}>Limpar</Button>
                  </div>
                </SchemaForm>
              </Col>
              <Col>
                <Form.Group>
                  <Form.Label>
                    <b>Requisição</b>
                    <Button
                      variant="success"
                      size="sm"
                      className="mb-3 ml-3"
                      style={{verticalAlign: '0px'}}
                      onClick={() => executeTest(test)}
                    >
                      Executar requisição
                    </Button>
                  </Form.Label>
                  <Form.Control
                    as="textarea"
                    rows={10}
                    value={formData ? JSON.stringify(formData, null, 4) : ''}
                    disabled={true}
                  />
                </Form.Group>
                <Form.Group>
                  <Form.Label>
                    <b>Resposta</b>
                    { response && !response.success && <Badge variant="danger" className="ml-2">Erro</Badge> }
                    { response && response.success && <Badge variant="success" className="ml-2">Sucesso</Badge> }
                  </Form.Label>
                  <Form.Control
                      as="textarea"
                      rows={10}
                      value={response ? JSON.stringify(response, null, 4) : ''}
                      disabled={true}
                  />
                </Form.Group>
              </Col>
            </>
          )}
        </Row>
      </Container>
    </div>
  );
}

export default App;
