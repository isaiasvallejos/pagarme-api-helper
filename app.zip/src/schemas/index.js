import address from './address'
import splitRules from './split-rules'

export default {
    address, splitRules
}