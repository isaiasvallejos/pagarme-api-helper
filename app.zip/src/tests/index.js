import createTransactionCreditCard from './create-transaction-credit-card';

export default [createTransactionCreditCard];
