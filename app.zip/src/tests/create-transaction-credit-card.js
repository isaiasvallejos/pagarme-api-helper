export default {
  id: 'create-transaction-credit-card',
  title: 'Criar Transação de Cartão de Crédito',
  generateSchema: ({ cards, recipients }, schemas) => {
    const schema = {
      stateSchemas: {
        recipients: {
          type: 'string',
          enum: recipients.map(recipient => recipient.id),
          enumNames: recipients.map(recipient => `${recipient.id} • ${recipient.bank_account.legal_name}`)
        },
        cards: {
          type: 'string',
          enum: cards.map(card => card.id),
          enumNames:cards.map(card => `${card.id} • ${card.holder_name}`),
        }
      },
      schemas,
      type: 'object',
      properties: {
        amount: {
          title: 'Amount',
          type: 'integer',
        },
        card_id: {
          title: 'Card',
          description: 'Utilize a referência de um cartão já anteriormente cadastrado.',
          $ref: "#/stateSchemas/cards"
        },
        card_holder_name: {
          title: 'Card Holder Name',
          type: 'string',
        },
        card_expiration_date: {
          title: 'Card Expiration Date',
          type: 'string',
        },
        card_number: {
          title: 'Card Number',
          type: 'string',
        },
        card_cvv: {
          title: 'Card CVV',
          type: 'string',
        },
        payment_method: {
          title: 'Payment Type',
          type: 'string',
          enum: ['credit_card'],
          enumNames: ['Credit Card'],
          default: 'credit_card',
        },
        installments: {
          title: 'Installments',
          type: 'number'
        },
        split_rules: {
          title: 'Split Rules',
          $ref: "#/schemas/splitRules"
        },
        customer: {
          title: 'Customer',
          type: 'object',
          properties: {
            external_id: {
              title: 'External ID',
              type: 'string'
            },
            name: {
              title: 'Name',
              type: 'string'
            },
            email: {
              title: 'E-mail',
              type: 'string'
            },
            country: {
              title: 'Country',
              type: 'string'
            },
            type: {
              title: 'Type',
              enum: ['individual', 'corporation'],
              enumNames: ['Individual', 'Corporation']
            },
            phone_numbers: {
              title: 'Customer • Phone Numbers',
              type: 'array',
              items: {
                title: 'Phone Number',
                type: 'string'
              }
            },
            documents: {
              title: 'Customer • Documents',
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  type: {
                    title: 'Type',
                    type: 'string',
                    enum: ['cnpj', 'cpf', 'passport', 'other'],
                    enumNames: ['CNPJ', 'CPF', 'Passaport', 'Other']
                  },
                  number: {
                    title: 'Number',
                    type: 'string'
                  }
                }
              }
            },
          },
        },
        billing: {
          title: 'Billing',
          type: 'object',
          properties: {
            name: {
              title: 'Name',
              type: 'string'
            },
            address: {
              title: 'Billing • Address',
              type: 'object',
              $ref: "#/schemas/address"
            }
          }
        },
        shipping: {
          title: 'Shipping',
          type: 'object',
          properties: {
            name: {
              title: 'Name',
              type: 'string'
            },
            fee: {
              title: 'Fee',
              type: 'number'
            },
            delivery_date: {
              title: 'Delivery Date',
              type: 'string'
            },
            expedited: {
              title: 'Expedited',
              type: 'boolean'
            },
            address: {
              title: 'Shipping • Address',
              type: 'object',
              $ref: "#/schemas/address"
            }
          }
        },
        items: {
          title: 'Items',
          type: 'array',
          items: {
            type: 'object',
            properties: {
              id: {
                title: 'ID/SKU',
                type: 'string'
              },
              title: {
                title: 'Nome',
                type: 'string'
              },
              unit_price: {
                title: 'Unit Price',
                type: 'number'
              },
              quantity: {
                title: 'Quantity',
                type: 'number'
              },
              tangible: {
                title: 'Tangible',
                type: 'boolean'
              },
              category: {
                title: 'Category',
                type: 'string'
              },
              venue: {
                title: 'Venue',
                type: 'string'
              },
              date: {
                title: 'Date',
                type: 'string'
              }
            }
          }
        },
        capture: {
          title: 'Capture',
          type: 'boolean'
        },
        async: {
          title: 'Async',
          type: 'boolean'
        },
        postback_url: {
          title: 'Postback URL',
          type: 'string'
        },
      },
    };

    return schema
  },
  createState: async client => {
    const cards = await client.cards.all();
    const recipients = await client.recipients.all();

    return { cards, recipients };
  },
  execute: async (client, data) => {
    return client.transactions.create(data)
  }
};
